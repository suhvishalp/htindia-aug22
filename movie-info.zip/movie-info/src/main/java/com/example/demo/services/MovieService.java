package com.example.demo.services;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Movie;
import com.example.demo.exeptions.ResourceNotFoundException;
import com.example.demo.payloads.MovieDTO;
import com.example.demo.repositories.MovieRepository;

@Service
public class MovieService {

	@Autowired
	private MovieRepository movieRepository;
	
	@Autowired
	private ModelMapper modelMapper;
	
	public Movie save(Movie movie) {
		return movieRepository.save(movie);
	}
	
	public MovieDTO getMovie(int movieId) {

		Movie movie = movieRepository.findById(movieId)
						.orElseThrow(()-> new ResourceNotFoundException("Movie", "movieID", ""+movieId));
		
//		MovieDTO movieDTO = new MovieDTO();
//		movieDTO.setTitle(movie.getTitle());
//		movieDTO.setDescription(movie.getDescription());
//		movieDTO.setMovieId(movie.getMovieId());
		
		MovieDTO movieDTO =  mapToDTO(movie);
		
		return movieDTO;

//		Optional<Movie> optMovie =  movieRepository.findById(movieId).orE
		
//		if( optMovie.isPresent()) { 
//			return optMovie.get() ; 
//		}else {
//			throw new ResourceNotFoundException("Movie", "movieId", movieId+"");
//		}
	}
	
	public List<MovieDTO> getAllMovies(){
		List<Movie> list = movieRepository.findAll();
		
		return list.stream()
					.map( movie -> mapToDTO(movie))
					.collect(Collectors.toList());
	}
	
	private MovieDTO mapToDTO(Movie movie) {
		return	modelMapper.map(movie, MovieDTO.class);
	}
	
}
