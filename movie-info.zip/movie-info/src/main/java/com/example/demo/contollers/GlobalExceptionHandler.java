package com.example.demo.contollers;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.example.demo.exeptions.ErrorDetails;
import com.example.demo.exeptions.ErrorInfo;
import com.example.demo.exeptions.ResourceNotFoundException;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<List<ErrorDetails>> handleInvalidMovieException(MethodArgumentNotValidException ex){
		
		List<FieldError> listErrors =  ex.getFieldErrors();
		
		List<ErrorDetails> listErrorDetails = listErrors.stream()
								.map( fieldError -> new ErrorDetails(fieldError.getField(), 
																	fieldError.getDefaultMessage()))				
								.collect(Collectors.toList());
		
		return new ResponseEntity<List<ErrorDetails>>(listErrorDetails, HttpStatus.BAD_REQUEST);
			
	}
	
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<ErrorInfo> handleResourceNotFoundException(ResourceNotFoundException ex, WebRequest request) {
		ErrorInfo errorInfo = new ErrorInfo(new Date(), ex.getMessage(), request.getDescription(false));
		return new ResponseEntity<ErrorInfo>(errorInfo, HttpStatus.NOT_FOUND);
	}

}
