package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.Movie;

@Repository
public interface MovieRepository extends JpaRepository<Movie, Integer> {

//	|--> long	count()
//    |--> void	delete(T entity)
//    |--> void	deleteAll()
//	  |--> Optional<T> findById(ID id)
//    |--> <S extends T> S	save(S entity)
//    |--> Iterable<T>	findAll()

	List<Movie> findAllByDescription(String desc);
	
//	@Query(value = "SELECT m FROM MOVIE m where m.price >= :price")
//	List<Movie> getAllMoviesByPrice(@Param("price") int price);

	
	@Query(value = "SELECT * from movie where price >= :price", nativeQuery = true)
	List<Movie> getAllMoviesByPrice(@Param("price") int price);
	
	
	

}
